const express = require('express')
const app = express()
const bodyParser = require('body-parser')
const collection = require('./route/collection')
const product = require('./route/product')

app.use(bodyParser.json())
app.use(express.json())
app.use(
  bodyParser.urlencoded({
    extended: false
  })
)

app.use('/collection', collection)
app.use('/product', product)
app.use((err, req, res, next) => {
  res.status(err.status || 500)
  res.send(err.message)
})

module.exports = app

const express = require('express')
const router = express.Router()
const fs = require('fs')

router.get('/', (req, res) => {
  fs.readFile('data/collections.json', 'utf8', (err, data) => {
    if (err) {
      res.status(404).send(err)
    }
    res.status(200).send(JSON.parse(data))
  })
})

router.get('/:id', (req, res) => {
  let collectionObj = []
  fs.readFile('data/collections.json', 'utf8', (err, data) => {
    if (err) {
      res.status(404).send(err)
    }
    collectionObj = JSON.parse(data)

    for (let i = 0; i < collectionObj.length; i++) {
      if (collectionObj[i].id == req.params.id) {
        res.status(200).send(collectionObj[i])
      }
    }
  })
})

router.post('/', (req, res) => {
  let collectionObj = []
  fs.readFile('data/collections.json', 'utf8', (err, data) => {
    if (err) {
      res.send(err)
    } else {
      collectionObj = JSON.parse(data)
      let isUniqueId = collectionObj.some(element => element.id === req.body.id)
      if (!isUniqueId) {
        let col = {
          id: req.body.id,
          collection_name: req.body.collection_name
        }
        collectionObj[collectionObj.length] = col
        fs.writeFile(
          'data/collections.json',
          JSON.stringify(collectionObj),
          err => {
            if (err) throw err
            res.status(200).send({ Response: 'Success' })
          }
        )
      } else {
        res.status(404).send({ Response: 'you need to provide a unique id' })
      }
    }
  })
})
router.put('/update', (req, res) => {
  let collectionObj = []
  fs.readFile('data/collections.json', 'utf8', (err, data) => {
    if (err) {
      res.send(err)
    } else {
      collectionObj = JSON.parse(data)
      let indx = collectionObj.findIndex(element => element.id == req.query.id)
      if (indx > -1) {
        let col = {
          id: req.query.id,
          collection_name: req.body.collection_name
        }
        collectionObj[indx] = col
        fs.writeFile(
          'data/collections.json',
          JSON.stringify(collectionObj),
          err => {
            if (err) throw err
            res.status(200).send({ Response: 'Success' })
          }
        )
      } else {
        res.status(404).send({ Response: 'You need a valid ID to update data' })
      }
    }
  })
})
router.delete('/delete', (req, res) => {
  let collectionObj = []
  fs.readFile('data/collections.json', 'utf8', (err, data) => {
    if (err) {
      res.send(err)
    } else {
      collectionObj = JSON.parse(data)
      let indx = collectionObj.findIndex(element => element.id == req.query.id)
      if (indx > -1) {
        collectionObj.splice(indx, 1)
        fs.writeFile(
          'data/collections.json',
          JSON.stringify(collectionObj),
          err => {
            if (err) throw err
            res.status(200).send({ Response: 'Success' })
          }
        )
      } else {
        res.status(404).send({ Response: 'You need a valid ID to delete data' })
      }
    }
  })
})

module.exports = router

const express = require('express')
const router = express.Router()
const fs = require('fs')

router.get('/', (req, res) => {
  fs.readFile('data/products.json', 'utf8', (err, data) => {
    if (err) {
      res.status(404).send(err)
    }
    res.status(200).send(JSON.parse(data))
  })
})

router.get('/:id', (req, res) => {
  let productObj = []
  fs.readFile('data/products.json', 'utf8', (err, data) => {
    if (err) {
      res.status(404).send(err)
    }
    productObj = JSON.parse(data)
    for (let i = 0; i < productObj.length; i++) {
      if (productObj[i].id == req.params.id) {
        res.status(200).send(productObj[i])
      }
    }
  })
})

router.post('/', (req, res) => {
  let productObj = []
  fs.readFile('data/products.json', 'utf8', (err, data) => {
    if (err) {
      res.send(err)
    } else {
      productObj = JSON.parse(data)
      let isUniqueId = productObj.some(element => element.id === req.body.id)
      if (!isUniqueId) {
        let col = {
          id: req.body.id,
          product_name: req.body.product_name,
          product_collections: req.body.product_collections
        }
        productObj[productObj.length] = col
        fs.writeFile(
          'data/products.json',
          JSON.stringify(productObj),

          err => {
            if (err) throw err
            res.status(200).send({ Response: 'Success' })
          }
        )
      } else {
        res.status(404).send({ Response: 'you need to provide a unique id' })
      }
    }
  })
})
router.put('/update', (req, res) => {
  let productObj = []
  fs.readFile('data/products.json', 'utf8', (err, data) => {
    if (err) {
      res.send(err)
    } else {
      productObj = JSON.parse(data)
      console.log(req.query.product_id)

      let indx = productObj.findIndex(
        element => element.id == req.query.product_id
      )
      console.log(indx)
      if (indx > -1) {
        let col = {
          id: req.query.product_id,
          collection_name: req.body,
          product_collections: req.body.product_collections
        }
        productObj[indx].product_collections =  JSON.stringify(req.body)
        let abd = productObj[indx]
        fs.writeFile('data/productsUpdated.json', JSON.stringify(productObj), err => {
          if (err) throw err
          res.status(200).send({ Response: 'Success' })
        })
      } else {
        res.status(404).send({ Response: 'You need a valid ID to update data' })
      }
    }
  })
})
router.delete('/delete', (req, res) => {
  let productObj = []
  fs.readFile('data/products.json', 'utf8', (err, data) => {
    if (err) {
      res.send(err)
    } else {
      productObj = JSON.parse(data)
      let indx = productObj.findIndex(element => element.id == req.query.id)
      if (indx > -1) {
        productObj.splice(indx, 1)
        fs.writeFile('data/products.json', JSON.stringify(productObj), err => {
          if (err) throw err
          res.status(200).send({ Response: 'Success' })
        })
      } else {
        res.status(404).send({ Response: 'You need a valid ID to delete data' })
      }
    }
  })
})

module.exports = router
